<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="./assets/ikki.css">
    <title>Document</title>
</head>
<body>
<div class="background-image"></div>    
<nav class="navbar">
  <div class="container">
    <h1>Valyuta Kurslari</h1>
    <ul class="menu">
      <li><a href="#"><i class="fas fa-dollar-sign"></i> USD: 12,667</a></li>
      <li><a href="#"><i class="fas fa-euro-sign"></i> EUR: 13,481</a></li>
      <li><a href="#"><i class="fas fa-pound-sign"></i> RUB: 135.77</a></li>
    </ul>
  </div>
</nav>
<div class="buttons">
    <form action="olish.php">
        <button><i class="fas fa-dollar-sign"></i>Valyuta olish</button>
    </form>
    <form action="sotish.php">
        <button><i class="fas fa-dollar-sign"></i>Valyuta Sotish</button>
    </form>   
</div>
</body>
</html>