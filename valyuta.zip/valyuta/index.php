<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buttonlar va Maydon Fon</title>
<link rel="stylesheet" href="./assets/bir.css">
</head>
<body>
<div class="container">
  <div class="background-image"></div>
  <div class="buttons">
    <form action="tanlov.php">
        <button>O'zbek Tili</button>
        <button>Rus Tili</button>
        <button>Ingliz Tili</button>
    </form>
  </div>
</div>
</body>
</html>
